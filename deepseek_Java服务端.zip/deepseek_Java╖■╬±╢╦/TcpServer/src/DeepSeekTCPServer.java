import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.net.http.*;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import org.json.JSONObject;

public class DeepSeekTCPServer {

    public static void main(String[] args) throws Exception {
        ServerSocket serverSocket = new ServerSocket(5000); // ESP8266 连接此端口
        System.out.println("等待ESP8266连接...");

        Socket socket = serverSocket.accept();
        System.out.println("ESP8266已连接: " + socket.getInetAddress());

        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), "GBK"));
        BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "GBK"));


        String inputLine;
        while ((inputLine = in.readLine()) != null) {
            System.out.println("接收到瑞萨数据: " + inputLine);

            // 只提取第一次出现 </think> 后面的所有内容
            String contentToSend = inputLine;
            int endThinkIndex = inputLine.indexOf("</think>");
            if (endThinkIndex != -1) {
                contentToSend = inputLine.substring(endThinkIndex + "</think>".length());
            }

            // 发送到本地 DeepSeek
            String response = askOllama(contentToSend);
            System.out.println("Ollama 回复: " + response);

            // 发回 ESP8266 → 瑞萨，结尾加上 sendsuccess
            out.write(response + "\r\nthink_succeed\r\n");
            out.flush();
        }

        socket.close();
        serverSocket.close();
    }

    public static String askOllama(String userInput) throws Exception {
        HttpClient client = HttpClient.newHttpClient();

        String json = """
                {
                  "model": "deepseek-r1",
                  "messages": [
                    {"role": "user", "content": "%s"}
                  ]
                }
                """.formatted(userInput);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:12516/api/chat"))
                .header("Content-Type", "application/json")
                .POST(BodyPublishers.ofString(json))
                .build();

        StringBuilder fullResponse = new StringBuilder();
        boolean done = false;

        // 用 try-with-resources 自动关闭 InputStream 和 BufferedReader
        HttpResponse<InputStream> response = client.send(request, BodyHandlers.ofInputStream());
        try (InputStream is = response.body();
             BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println("收到数据块: " + line);
                try {
                    JSONObject jsonResponse = new JSONObject(line);

                    // 获取 content 字段
                    if (jsonResponse.has("message")) {
                        JSONObject message = jsonResponse.getJSONObject("message");
                        if (message.has("content")) {
                            fullResponse.append(message.getString("content"));
                        }
                    }

                    // 判断是否 done，结束拼接
                    if (jsonResponse.has("done") && jsonResponse.getBoolean("done")) {
                        done = true;
                    }

                } catch (Exception e) {
                    System.out.println("解析错误: " + e.getMessage());
                }

                if (done) {
                    break;
                }
            }
        }

        return fullResponse.toString();
    }
}
