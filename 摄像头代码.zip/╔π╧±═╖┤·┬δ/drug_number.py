from maix import camera, display, image, nn, app, touchscreen ,uart
import time
last_print_time = time.time()

detector = nn.YOLOv5(model="/root/models/maixhub/model-218153.maixcam/model_218153.mud")

cam = camera.Camera(detector.input_width(), detector.input_height(), detector.input_format())
dis = display.Display()

received_data = b""
app_switch_face_flag = False
start_recognize_flag = False

def on_received(serial : uart.UART, data : bytes):
    global received_data
    received_data = data
    print("UART received:", data)

device = "/dev/ttyS0"

serial0 = uart.UART(device, 115200)
serial0.set_received_callback(on_received)
serial0.write_str("drug_app_ok\r\n")


# 初始化触摸屏驱动
ts = touchscreen.TouchScreen()
ts.open()
down_flag = False
back_flag = False

# 定义要识别的目标类别
TARGET_CLASSES = ["red", "blue", "green"]
# 获取目标类别的ID
target_class_ids = [detector.labels.index(cls) for cls in TARGET_CLASSES if cls in detector.labels]

# 检查是否所有目标类别都存在
if len(target_class_ids) != len(TARGET_CLASSES):
    missing = [cls for cls in TARGET_CLASSES if cls not in detector.labels]
    print(f"Warning: Missing classes in model: {missing}")

# 用于检测数量是否稳定的变量
last_counts = {"red": -1, "blue": -1, "green": -1}  # 初始值设为-1
stable_count = 0  # 连续稳定的次数

while not app.need_exit():
    img = cam.read()
    objs = detector.detect(img, conf_th=0.5, iou_th=0.45)
    
    if b"switchface" in received_data:
        app_switch_face_flag= True
    if b"startrecognize" in received_data:
        start_recognize_flag= True
    received_data = b""

    if app_switch_face_flag:
        app_switch_face_flag= False
        app.set_exit_flag(True)  # 触发退出
        # 释放硬件资源
        cam.close()
        dis.close()
        ts.close()
        time.sleep(1)  # 增加释放缓冲时间
        # 启动第二个应用（假设路径正确）
        app.switch_app(app_id="drug_face_recognize", start_param="mode=debug")

    if start_recognize_flag:
        # 初始化计数器
        count_dict = {cls: 0 for cls in TARGET_CLASSES}
        
        for obj in objs:
            # 获取类别名称
            class_name = detector.labels[obj.class_id]
            
            # 设置不同类别的颜色的检测框
            if class_name == "red":
                color = image.COLOR_RED
            elif class_name == "blue":
                color = image.COLOR_BLUE
            elif class_name == "green":
                color = image.COLOR_GREEN
            else:
                color = image.COLOR_WHITE  # 其他类别用白色
            
            # 绘制检测框和标签
            img.draw_rect(obj.x, obj.y, obj.w, obj.h, color=color)
            msg = f'{class_name}: {obj.score:.2f}'
            img.draw_string(obj.x, obj.y, msg, color=color)
            
            # 统计目标类别数量
            if obj.class_id in target_class_ids:
                count_dict[class_name] += 1

        # 检查数量是否变化
        current_counts = {
            "red": count_dict["red"],
            "blue": count_dict["blue"],
            "green": count_dict["green"]
        }
        
        # 比较当前数量与上一次数量
        counts_changed = False
        for color in TARGET_CLASSES:
            if current_counts[color] != last_counts[color]:
                counts_changed = True
                break
        
        # 更新上一次的数量记录
        last_counts = current_counts.copy()
        
        # 处理稳定性计数
        if counts_changed:
            stable_count = 0  # 数量变化，重置稳定计数器
        else:
            stable_count += 1  # 数量未变化，增加稳定计数器
        
        # 每秒钟检查一次是否需要打印
        if (time.time() - last_print_time) >= 0.5:
            # 如果连续3次（3秒）数量不变，则打印
            if stable_count >= 10:
                serial0.write_str(f"red:{count_dict['red']},blue:{count_dict['blue']},green:{count_dict['green']}\r\n")
                # 重置稳定计数器，避免连续打印
                stable_count = 0
                start_recognize_flag = False
            
            last_print_time = time.time()
        
        # 在屏幕上显示统计结果（使用不同颜色）
        y_position = img.height() - 30
        for i, (cls, count) in enumerate(count_dict.items()):
            color = image.COLOR_RED if cls == "red" else \
                    image.COLOR_BLUE if cls == "blue" else \
                    image.COLOR_GREEN
                    
            text = f"{cls.capitalize()}: {count}"
            img.draw_string(10, y_position - i*30, text, color=color, scale=1.2)
    
    # 读取触摸屏状态
    screen_status = ts.read()
    
    # 处理退出按钮释放
    if down_flag:
        if back_flag and screen_status[2] == 0:
            app.set_exit_flag(True)
    
    # 绘制UI界面
    img.draw_rect(5, 10, 50, 25, 
                 color=image.Color.from_rgb(113, 20, 147),
                 thickness=-1)
    img.draw_string(10, 15, "back",
                   color=image.Color.from_rgb(255, 255, 255))
    
    # 处理触摸按下事件
    if screen_status[2] == 1:
        if (96 < screen_status[0] < 196 and 10 < screen_status[1] < 60):
            back_flag = True
            down_flag = True
    
    # 显示图像
    dis.show(img)