from sys import float_repr_style
from typing import dataclass_transform
from maix import nn, camera, display, image, time, touchscreen, app,uart
import os  # 提供操作系统级别的文件路径操作和文件存在性检查的关键功能，无需保存人脸可注释掉
import math  

pressed_flag = [False, False, False]  # 触摸按钮状态标记
received_data = b""
serial_learn_name = None  # 存储从串口解析出的名字
face_count = 0
received_flag = False
app_switch_drug_number_flag= False

def on_received(serial : uart.UART, data : bytes):
    global received_data
    received_data = data
    print("UART received:", data)

device = "/dev/ttyS0"

serial0 = uart.UART(device, 115200)
serial0.set_received_callback(on_received)

serial0.write_str("face_app_ok\r\n")


def main(disp):
    global pressed_flag,  serial_learn_name
     # 初始化加载界面
    img = image.Image(disp.width(), disp.height())  # 创建与屏幕同尺寸的图像对象
    msg = "loading ..."
    size = image.string_size(msg, scale=2, thickness=2)  # 计算文字尺寸
    img.draw_string((img.width() - size.width()) // 2, (img.height() - size.height()) // 2, 
                   msg, color=image.COLOR_WHITE, scale=2, thickness=2)  # 居中绘制文字
    disp.show(img)

    recognizer = nn.FaceRecognizer(
        detect_model="/root/models/yolov8n_face.mud",
        feature_model="/root/models/insghtface_webface_r50.mud",
        dual_buff=True
    )
     # ===== 历史数据加载与learn_id初始化 =====
    if os.path.exists("/root/faces.bin"):
        recognizer.load_faces("/root/faces.bin")  
     
    cam = camera.Camera(recognizer.input_width(), recognizer.input_height(), recognizer.input_format())
    # cam.hmirror = True   # 水平镜像
    # cam.vflip = True
    ts = touchscreen.TouchScreen()  # 初始化触摸屏

    back_btn_pos = (0, 0, 70, 30)        # 返回按钮（左上角）
    learn_btn_pos = (0, recognizer.input_height() - 30, 60, 30)  # 学习按钮（左下角）
    clear_btn_pos = (recognizer.input_width() - 60, recognizer.input_height() - 30, 60, 30) # 清除按钮（右下角）

    back_btn_disp_pos = image.resize_map_pos(cam.width(), cam.height(), disp.width(), disp.height(), image.Fit.FIT_CONTAIN, back_btn_pos[0], back_btn_pos[1], back_btn_pos[2], back_btn_pos[3])
    learn_btn_disp_pos = image.resize_map_pos(cam.width(), cam.height(), disp.width(), disp.height(), image.Fit.FIT_CONTAIN, learn_btn_pos[0], learn_btn_pos[1], learn_btn_pos[2], learn_btn_pos[3])
    clear_btn_disp_pos = image.resize_map_pos(cam.width(), cam.height(), disp.width(), disp.height(), image.Fit.FIT_CONTAIN, clear_btn_pos[0], clear_btn_pos[1], clear_btn_pos[2], clear_btn_pos[3])
    # 按钮绘制函数(仅有显示功能)
    def draw_btns(img : image.Image):#定义一个名为 draw_btns 的函数，接收一个 image.Image 类型的图像对象 img。
        img.draw_rect(back_btn_pos[0], back_btn_pos[1], back_btn_pos[2], back_btn_pos[3], 
                     image.Color.from_rgb(255, 255, 255), 2)
        img.draw_string(back_btn_pos[0] + 4, back_btn_pos[1] + 8, "< back", image.COLOR_WHITE)
        img.draw_rect(learn_btn_pos[0], learn_btn_pos[1], learn_btn_pos[2], learn_btn_pos[3], 
                     image.Color.from_rgb(255, 255, 255), 2)
        img.draw_string(learn_btn_pos[0] + 4, learn_btn_pos[1] + 8, "learn", image.COLOR_WHITE)
        img.draw_rect(clear_btn_pos[0], clear_btn_pos[1], clear_btn_pos[2], clear_btn_pos[3], 
                     image.Color.from_rgb(255, 255, 255), 2)
        img.draw_string(clear_btn_pos[0] + 4, clear_btn_pos[1] + 8, "clear", image.COLOR_WHITE)

    #触摸点检测
    def is_in_button(x, y, btn_pos):
        # 判断坐标是否在按钮区域内
        return (x > btn_pos[0] and x < btn_pos[0] + btn_pos[2] and 
                y > btn_pos[1] and y < btn_pos[1] + btn_pos[3])

    # 触摸事件处理函数
    def on_touch(x, y, pressed):
        global pressed_flag, learn_id
        if pressed:  # 按下事件
            # 检测按下的按钮并记录状态
            if is_in_button(x, y, back_btn_disp_pos):
                pressed_flag[2] = True
            elif is_in_button(x, y, learn_btn_disp_pos):
                pressed_flag[0] = True
            elif is_in_button(x, y, clear_btn_disp_pos):
                pressed_flag[1] = True
            else:
                pressed_flag = [False, False, False]  # 点击其他区域取消所有按钮状态
        else:  # 释放事件
            # 根据记录的按下状态触发相应操作
            if pressed_flag[0]:
                print("learn btn click")
                pressed_flag[0] = False
                return True, False, False  # 返回（学习, 清除, 返回）状态，通知主循环添加新人脸。
            if pressed_flag[1]:
                print("clear btn click")
                pressed_flag[1] = False
                learn_id = 0  # 重置学习ID
                return False, True, False
            if pressed_flag[2]:
                print("back btn click")
                pressed_flag[2] = False
                return False, False, True
        return False, False, False

    # 初始化学习相关变量
    last_learn_img = None  # 存储最后学习的人脸图像
    last_learn_t = 0       # 记录最后学习时间

    while not app.need_exit():
        global received_data
        global received_flag
        global app_switch_drug_number_flag
        if received_data:
        # 将字节数据转为字符串
            data_str = received_data.decode('utf-8').strip()
            print("Received string:", data_str)
            
            # 检查是否包含"maixlearn:"前缀
            if data_str.startswith("maixlearn:"):
                # 分割字符串，提取名字部分
                name_part = data_str.split(':', 1)[1].strip()
                if name_part:
                    serial_learn_name = name_part
                    print(f"Extracted name: {serial_learn_name}")
                    pressed_flag[0] = True
            # if b"maixlearn" in received_data:
            #     pressed_flag[0]=True
            if b"maixclear" in received_data:
                pressed_flag[1]=True
            if b"maixback" in received_data:
                pressed_flag[2]=True
            if b"maixstart" in received_data:
                received_flag=True
            if b"switchdrug" in received_data:
                app_switch_drug_number_flag=True
            received_data = b""
        # 处理触摸事件
        x, y, pressed = ts.read()
        learn, clear, back = on_touch(x, y, pressed)
        
        if back:    # 返回按钮处理
            break
        elif clear: # 清除所有已学习人脸
            for i in range(len(recognizer.labels) - 1):
                recognizer.remove_face(0)

        # 获取摄像头画面
        img = cam.read().rotate(angle=180)
        # 运行人脸识别（参数分别为：图像，检测阈值，NMS阈值，特征匹配阈值，是否启用学习模式）
        faces = recognizer.recognize(img, 0.5, 0.45, 0.85, learn, learn)
        
        # 遍历检测到的人脸
        for obj in faces:
            # 打印人脸识别结果
            if received_flag:
                if obj.class_id == 0:
                    print(f"unfamiliar 置信度: {obj.score:.2f}")
                else:
                    global face_count
                    face_count += 1
                    print(f"识别到: ID={obj.class_id}, 名称='{recognizer.labels[obj.class_id]}', 置信度={obj.score:.2f},face_count={face_count}")
                    if face_count==3:
                        serial0.write_str(f"recognize:{recognizer.labels[obj.class_id]}\r\n")
                        face_count = 0
                        received_flag = False

            color = image.COLOR_RED if obj.class_id == 0 else image.COLOR_GREEN  # 红色表示陌生人，绿色表示已知
            # 绘制人脸框
            img.draw_rect(obj.x, obj.y, obj.w, obj.h, color=color)
            # 绘制人脸关键点（根据人脸宽度调整点大小）
            radius = math.ceil(obj.w / 10)
            img.draw_keypoints(obj.points, color, size=radius if radius < 5 else 4)
            # 显示标签和置信度
            msg = f'{recognizer.labels[obj.class_id]}: {obj.score:.2f}'
            img.draw_string(obj.x, obj.y - 10, msg, color=color)
            
            # 学习模式处理
            if learn and obj.class_id == 0:  # 检测到陌生人时学习
                name = f"{serial_learn_name}"
                recognizer.add_face(obj, name)  # 添加新人脸到数据库
            if learn:  # 记录学习时的人脸图像
                last_learn_img = obj.face
                last_learn_t = time.ticks_s()
        
        serial_learn_name = None
        # 在左上角显示最近学习的人脸（持续5秒）
        if last_learn_img and time.ticks_s() - last_learn_t < 5:
            img.draw_image(0, 0, last_learn_img)
        
        # 保存人脸数据库
        if learn:
            recognizer.save_faces("/root/faces.bin")
        
        # 绘制界面元素
        draw_btns(img)
        disp.show(img)
        
        if app_switch_drug_number_flag:
            app_switch_drug_number_flag=False
            app.set_exit_flag(True)  # 触发退出
            # 释放硬件资源
            cam.close()
            disp.close()
            ts.close()
            time.sleep(1)  # 增加释放缓冲时间
            # 启动第二个应用（假设路径正确）
            app.switch_app(app_id="drug_number", start_param="mode=debug")

disp = display.Display()
try:
    main(disp)          
except Exception:     
    # 异常处理：显示错误信息
    import traceback
    msg = traceback.format_exc()
    img = image.Image(disp.width(), disp.height())
    img.draw_string(0, 0, msg, image.COLOR_WHITE)
    disp.show(img)      # 将错误信息整合成一张图像显示到屏幕
    while not app.need_exit():
        time.sleep_ms(100)