#ifndef _max_i2c_H
#define _max_i2c_H
#include "headfile.h"
 
#define SCL_H              R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_06_PIN_08, BSP_IO_LEVEL_HIGH)
#define SCL_L              R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_06_PIN_08, BSP_IO_LEVEL_LOW)
 
#define SDA_H              R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_07_PIN_08, BSP_IO_LEVEL_HIGH)
#define SDA_L              R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_07_PIN_08, BSP_IO_LEVEL_LOW)
#define MAX_INT_H          R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_06_PIN_00, BSP_IO_LEVEL_HIGH)

//#define SCL_H              R_BSP_PinWrite(BSP_IO_PORT_04_PIN_08, BSP_IO_LEVEL_HIGH)
//#define SCL_L              R_BSP_PinWrite(BSP_IO_PORT_04_PIN_08, BSP_IO_LEVEL_LOW)
//#define SDA_H              R_BSP_PinWrite(BSP_IO_PORT_04_PIN_07, BSP_IO_LEVEL_HIGH)
//#define SDA_L              R_BSP_PinWrite(BSP_IO_PORT_04_PIN_07, BSP_IO_LEVEL_LOW)
//#define MAX_INT_H          R_BSP_PinWrite(BSP_IO_PORT_06_PIN_00, BSP_IO_LEVEL_HIGH)

#define SCL_read           R_BSP_PinRead(BSP_IO_PORT_04_PIN_08)
#define SDA_read           R_BSP_PinRead(BSP_IO_PORT_04_PIN_07)
#define MAX_INT_read       R_BSP_PinRead(BSP_IO_PORT_06_PIN_00)
#define bool int
#define TRUE 1
#define FALSE 0
 
void I2C_delay(void);
void IIC_Start(void);
void IIC_Stop(void);
uint8_t IIC_Wait_Ack(void);
void IIC_Ack(void);
void IIC_NAck(void);
void IIC_Send_Byte(uint8_t SendByte);
uint8_t IIC_Read_Byte(unsigned char ack);
void IIC_WriteBytes(uint8_t WriteAddr,uint8_t* data,uint8_t dataLength);
void IIC_ReadBytes(uint8_t deviceAddr, uint8_t writeAddr,uint8_t* data,uint8_t dataLength);
void IIC_Read_One_Byte(uint8_t daddr,uint8_t addr,uint8_t* data);
void IIC_Write_One_Byte(uint8_t daddr,uint8_t addr,uint8_t data);

#endif
