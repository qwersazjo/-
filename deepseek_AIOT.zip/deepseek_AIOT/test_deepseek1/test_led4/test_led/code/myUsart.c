#include "headfile.h"

volatile bool send_finish_flag=false;
volatile bool LCD_finish_flag=false;
volatile bool Audio_finish_flag=false;
uint8_t rec_buf[20],uart6_rec_buf[20],rec_data,count,wifi_buf[20]={0},wifi_count=0;
char send_buf1[50],send_buf2[50];

extern int rtc_alarm_sec_set;
extern int rtc_alarm_min_set;
extern int rtc_alarm_hour_set;
extern uint8_t angle;

bool wifi_flag;
const char *password1;
const char *wifi_name;

void USART_Init(void)
{
	R_SCI_UART_Open(&g_uart6_ctrl,&g_uart6_cfg);
}

void LCD_USART0_Init(void)
{
	R_SCI_UART_Open(&g_uart0_ctrl,&g_uart0_cfg);
}

void Audio_USART0_Init(void)
{
	R_SCI_UART_Open(&audio_uart7_ctrl,&audio_uart7_cfg);
}

void usart6_callback(uart_callback_args_t *p_args)
{
	switch(p_args->event)
	{
		case UART_EVENT_RX_CHAR:  //���յ�һ���ַ�
		{
			R_SCI_UART_Write(&g_uart6_ctrl,(uint8_t *)&(p_args->data),1);  //���ԣ�����ע��
			break;
		}
		case UART_EVENT_TX_COMPLETE:  //�������
		{
			send_finish_flag=true;
			break;
		}
		default:
			break;
	}
}

void lcd_uart0_callback(uart_callback_args_t *p_args)
{
	switch(p_args->event)
	{
		case UART_EVENT_RX_CHAR:  //���յ�һ���ַ�
		{
//-----------------����WIFI����----------------------//			
			R_SCI_UART_Write(&g_uart6_ctrl,(uint8_t *)&(p_args->data),1);	  //����
			rec_buf[count++]=p_args->data;
			wifi_buf[wifi_count++]=p_args->data;
			if(wifi_count==4)
			{
				if(memcmp(rec_buf, "1234", 4) == 0)
				{
					wifi_flag=1;
					if(wifi_flag==1)
					{
						password1="135200877498";
						wifi_name="YY";
					}
				}
				memset(wifi_buf,0,20);
				wifi_count=0;
				break;
			}
//-----------------����ʶ����----------------------//		
			if(p_args->data == 'u')	
			{
				LED_ON();
				sprintf(send_buf1,"maixstart");
				R_SCI_UART_Write(&g_uart6_ctrl,(uint8_t *)send_buf1,strlen(send_buf1));
				count=0;
				memset(rec_buf,0,20);
				break;
			}
//-----------------¼��ҩƷ��Ϣ����----------------------//	������
			if(p_args->data =='w')	
			{
				LED_ON();
				count=0;
				memset(rec_buf,0,20);
				break;
			}
//-----------------¼��������Ϣ����----------------------//	
			if(count == 8) 
			{
				if(memcmp(rec_buf, "xiaoming", 8) == 0)
				{
					if(rec_buf[0]=='x'&&rec_buf[1]=='i'&&rec_buf[2]=='a'&&rec_buf[3]=='o'&&rec_buf[4]=='m'&&rec_buf[5]=='i'&&rec_buf[6]=='n'&&rec_buf[7]=='g')
					{
						sprintf(send_buf1,"maixlearn:xiaoming");
						R_SCI_UART_Write(&g_uart6_ctrl,(uint8_t *)send_buf1,strlen(send_buf1));
						LED_OFF();
						count=0;
						memset(rec_buf,0,20);
						break;
					}
				}
			}
//-----------------RTC����----------------------//	
			if(count==3)
			{
				rtc_alarm_hour_set=rec_buf[0];
				rtc_alarm_min_set=rec_buf[1];
				rtc_alarm_sec_set=rec_buf[2];
				RTC_Alarm_Init();
				memset(rec_buf,0,20);
				break;
			}
			break;
		}
		case UART_EVENT_TX_COMPLETE:  //�������
		{
			LCD_finish_flag=true;
			break;
		}
		default:
			break;
	}
}

void audio_uart7_callback(uart_callback_args_t *p_args)
{
	switch(p_args->event)
	{
		case UART_EVENT_RX_CHAR:  //���յ�һ���ַ�
		{
			R_SCI_UART_Write(&g_uart6_ctrl,(uint8_t *)&(p_args->data),1);
			if(p_args->data ==0x00000001)	
			{
				LED_ON();
				angle=82;
				GPT_PWM_SetDuty(angle);
			}
			else if(p_args->data ==0x00000002)	
			{
				angle=63;
				GPT_PWM_SetDuty(angle);
				LED_OFF();
			}
			else if(p_args->data ==0x00000003)	
			{
				angle=44;
				GPT_PWM_SetDuty(angle);
				LED_ON();
			}
			else if(p_args->data ==0x00000004)	
			{
				angle=25;
				GPT_PWM_SetDuty(angle);
				LED_OFF();
			}
			else if(p_args->data ==0x00000005)	
			{
				angle=120;
				GPT_PWM_SetDuty(angle);
				LED_OFF();
			}
			else if(p_args->data ==0x00000006)	
			{
				angle=139;
				GPT_PWM_SetDuty(angle);
				LED_OFF();
			}
			else if(p_args->data ==0x00000007)	
			{
				angle=158;
				GPT_PWM_SetDuty(angle);
				LED_OFF();
			}
			break;
		}
		case UART_EVENT_TX_COMPLETE:  //�������
		{
			Audio_finish_flag=true;
			break;
		}
		default:
			break;
	}
}

void touch_led_send(char led_id[],char led_txt[])
{
	sprintf(send_buf2,"AI_answer.%s.txt=\"%s\"\xff\xff\xff",led_id,led_txt); 
	R_SCI_UART_Write(&g_uart0_ctrl,(uint8_t *)send_buf2,strlen(send_buf2)+3);
}

void page_send(char led_txt[])
{
	sprintf(send_buf2,"page %s\xff\xff\xff",led_txt); 
	R_SCI_UART_Write(&g_uart0_ctrl,(uint8_t *)send_buf2,strlen(send_buf2)+3);
}

int fputc(int ch,FILE *f)  //�����ض���
{
	(void)f;
	R_SCI_UART_Write(&g_uart6_ctrl,(uint8_t *)&ch,1);
	while(send_finish_flag==false){}
	send_finish_flag=false;
	return ch;
}
