#include "bsp_dtc.h"
#include "headfile.h"
// �������� - ��ʼֵȡ��ԭ�궨��
int rtc_year_set = 2025;
int rtc_mon_set = 7;
int rtc_mday_set = 9;
int rtc_sec_set = 0;
int rtc_min_set = 0;
int rtc_hour_set = 0;

int rtc_alarm_year_set = 2025;
int rtc_alarm_mon_set = 7;
int rtc_alarm_mday_set = 9;
int rtc_alarm_sec_set = 15;
int rtc_alarm_min_set = 0;
int rtc_alarm_hour_set = 0;

int rtc_alarm_year_enable = 0;
int rtc_alarm_mon_enable = 0;
int rtc_alarm_mday_enable = 0;
int rtc_alarm_wday_enable = 0;
int rtc_alarm_sec_enable = 1;
int rtc_alarm_min_enable = 1;
int rtc_alarm_hour_enable = 1;

// �������ڵĺ��������ԭ�꣩
int calculate_wday(int year, int mon, int mday) {
    return (year - 2000 + (year - 2000)/4 - 35 + 
           (26 * (mon + 1))/10 + mday - 1) % 7;
}

void RTC_Alarm_Init(void) {
    // �������ӵ�����
    int alarm_wday = calculate_wday(rtc_alarm_year_set, 
                                   rtc_alarm_mon_set, 
                                   rtc_alarm_mday_set);
    
    rtc_alarm_time_t alarm_time = {
        .time = {
            .tm_sec = rtc_alarm_sec_set,   // ��
            .tm_min = rtc_alarm_min_set,   // ��
            .tm_hour = rtc_alarm_hour_set, // Сʱ
            .tm_mday = rtc_alarm_mday_set, // ��
            .tm_wday = alarm_wday,        // ���ڣ���̬���㣩
            .tm_mon = rtc_alarm_mon_set - 1, // �·�
            .tm_year = rtc_alarm_year_set - 1900, // ���
        },
        .dayofweek_match = rtc_alarm_wday_enable,
        .hour_match = rtc_alarm_hour_enable,
        .mday_match = rtc_alarm_mday_enable,
        .min_match = rtc_alarm_min_enable,
        .mon_match = rtc_alarm_mon_enable,
        .sec_match = rtc_alarm_sec_enable,
        .year_match = rtc_alarm_year_enable,
    };
    R_RTC_CalendarAlarmSet(rtc.p_ctrl, &alarm_time);
}

void RTC_Init(void) {
    // �����ʼʱ�������
    int init_wday = calculate_wday(rtc_year_set, 
                                  rtc_mon_set, 
                                  rtc_mday_set);
    
    // ��ʼ��ʱ�趨��ʱ��
    rtc_time_t set_time = {
        .tm_sec = rtc_sec_set,   // ��
        .tm_min = rtc_min_set,   // ��
        .tm_hour = rtc_hour_set, // Сʱ
        .tm_mday = rtc_mday_set, // ��
        .tm_wday = init_wday,   // ���ڣ���̬���㣩
        .tm_mon = rtc_mon_set - 1,   // �·�
        .tm_year = rtc_year_set - 1900, // ���
    };

    /* ��RTCģ�� */
    R_RTC_Open(rtc.p_ctrl, rtc.p_cfg);
    
    /* ʱ��Դ���� */
    R_RTC_ClockSourceSet(rtc.p_ctrl);
    
    /* ���õ�ǰʱ�� */
    R_RTC_CalendarTimeSet(rtc.p_ctrl, &set_time);
    
    /* ���������ж�Ϊ1�� */
    R_RTC_PeriodicIrqRateSet(rtc.p_ctrl, RTC_PERIODIC_IRQ_SELECT_1_SECOND);
}

void rtc_callback(rtc_callback_args_t *p_args) {
    static rtc_time_t get_time;
    
    switch (p_args->event) {
        case RTC_EVENT_PERIODIC_IRQ:
            R_RTC_CalendarTimeGet(rtc.p_ctrl, &get_time);
//			 ESP8266_DEBUG_MSG("\r\n%d-%d-%d-%d:%d:%d\r\n", get_time.tm_year + 1900, get_time.tm_mon + 1, get_time.tm_mday,
//						 get_time.tm_hour, get_time.tm_min, get_time.tm_sec);
				break;
            
        case RTC_EVENT_ALARM_IRQ:
            R_RTC_CalendarTimeGet(rtc.p_ctrl, &get_time);
            ESP8266_DEBUG_MSG("\r\n%d-%d-%d-%d:%d:%d\r\n", 
                  get_time.tm_year + 1900, 
                  get_time.tm_mon + 1, 
                  get_time.tm_mday,
                  get_time.tm_hour, 
                  get_time.tm_min, 
                  get_time.tm_sec);

            break;
            
        default:
            break;
    }
}