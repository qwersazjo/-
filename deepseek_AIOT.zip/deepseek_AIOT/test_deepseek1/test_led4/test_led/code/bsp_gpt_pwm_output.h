#ifndef __BSP_GPT_PWM_OUTPUT_H
#define __BSP_GPT_PWM_OUTPUT_H
#include "hal_data.h"

void GPT_PWM_Init(void);

void GPT_PWM_SetDuty(uint8_t duty);

#endif
