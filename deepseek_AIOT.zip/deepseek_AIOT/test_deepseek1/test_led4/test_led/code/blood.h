#ifndef blood_h
#define blood_h
#include "headfile.h"

void blood_data_translate(void);
void blood_data_update(void);
void blood_Loop(void);

#endif
