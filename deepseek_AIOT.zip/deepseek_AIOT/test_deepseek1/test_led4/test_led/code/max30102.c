#include "headfile.h"
uint16_t fifo_red;  //����FIFO�еĺ������
uint16_t fifo_ir;   //����FIFO�еĺ��������
unsigned int timeout_ms = 500;

i2c_master_event_t g_i2c_callback_event;
static volatile bool iic_complete = false;

void I2C_max30102_ByteWrite(unsigned char address, unsigned char byte)
{
    iic_complete = false;
    unsigned char send_buffer[2] = {};

    send_buffer[0] = address;
    send_buffer[1] = byte;
    R_IIC_MASTER_Write(&max30102_i2c_ctrl, &send_buffer[0], 2, false); //ÿ��д������ false ��������

    while ((I2C_MASTER_EVENT_TX_COMPLETE != g_i2c_callback_event) && timeout_ms)
    {
        R_BSP_SoftwareDelay(1U, BSP_DELAY_UNITS_MILLISECONDS);
        timeout_ms--;
    }
    timeout_ms = 500;
}

void I2C_max30102_BufferRead(unsigned char* ptr_read,unsigned char address,unsigned char byte)
{

    unsigned char send_buffer[2] = {};
    unsigned char read_buffer[1] = {};

    send_buffer[0] = address;
    R_IIC_MASTER_Write(&max30102_i2c_ctrl, &send_buffer[0], 1, true);
    while ((I2C_MASTER_EVENT_TX_COMPLETE != g_i2c_callback_event) && timeout_ms)
    {
        R_BSP_SoftwareDelay(400U, BSP_DELAY_UNITS_MICROSECONDS);
        timeout_ms--;
    }
    timeout_ms = 500;

    R_BSP_SoftwareDelay(250U, BSP_DELAY_UNITS_MICROSECONDS);

    R_IIC_MASTER_Read(&max30102_i2c_ctrl, ptr_read, byte, false);

}

uint8_t max30102_write_reg(uint8_t addr, uint8_t data)
{  
	I2C_max30102_ByteWrite(addr,data);
	return 1;
}

uint8_t max30102_read_reg(uint8_t addr )
{ 
	uint8_t data=0; 
	I2C_max30102_BufferRead(&max30102_i2c_ctrl,addr, 1); 
	return data;
}

uint8_t Max30102_reset(void)
{  
	if(max30102_write_reg(REG_MODE_CONFIG, 0x40)) 
		return 1;    
	else        
		return 0;    
}

void MAX30102_Config(void)
{  
	max30102_write_reg(REG_INTR_ENABLE_1,0xc0); //INTR setting 
	max30102_write_reg(REG_INTR_ENABLE_2,0x00); 
	max30102_write_reg(REG_FIFO_WR_PTR,0x00);//FIFO_WR_PTR[4:0]  
	max30102_write_reg(REG_OVF_COUNTER,0x00);//OVF_COUNTER[4:0]  
	max30102_write_reg(REG_FIFO_RD_PTR,0x00);//FIFO_RD_PTR[4:0]    
	max30102_write_reg(REG_FIFO_CONFIG,0x0f);//sample avg = 1, fifo rollover=false, fifo almost full = 17  
	max30102_write_reg(REG_MODE_CONFIG,0x03);//0x02 for Red only, 0x03 for SpO2 mode 0x07 multimode LED  
	max30102_write_reg(REG_SPO2_CONFIG,0x27);  // SPO2_ADC range = 4096nA, SPO2 sample rate (50 Hz), LED pulseWidth (400uS)    
	max30102_write_reg(REG_LED1_PA,0x32);//Choose value for ~ 10mA for LED1  
	max30102_write_reg(REG_LED2_PA,0x32);// Choose value for ~ 10mA for LED2  
	max30102_write_reg(REG_PILOT_PA,0x7f);// Choose value for ~ 25mA for Pilot LED
}

void max30102_read_fifo(void)
{  
	uint16_t un_temp;  
	fifo_red=0;  fifo_ir=0;  
	uint8_t ach_i2c_data[6];    //read and clear status register  
	max30102_read_reg(REG_INTR_STATUS_1);  
	max30102_read_reg(REG_INTR_STATUS_2);    
	ach_i2c_data[0]=REG_FIFO_DATA;    
//	HAL_I2C_Mem_Read(&hi2c1,MAX30102_Device_address,REG_FIFO_DATA,1,ach_i2c_data,6,HAL_MAX_DELAY);   
	un_temp=ach_i2c_data[0];  
	un_temp<<=14; 
	fifo_red+=un_temp;  un_temp=ach_i2c_data[1];  
	un_temp<<=6;  fifo_red+=un_temp;  un_temp=ach_i2c_data[2];  
	un_temp>>=2;  fifo_red+=un_temp;    un_temp=ach_i2c_data[3];  
	un_temp<<=14;  fifo_ir+=un_temp;  un_temp=ach_i2c_data[4];  
	un_temp<<=6;  fifo_ir+=un_temp;  un_temp=ach_i2c_data[5];  un_temp>>=2; 
	fifo_ir+=un_temp;    
	if(fifo_ir<=10000)  
	{    
		fifo_ir=0;  
	}  
	if(fifo_red<=10000)  
	{    
		fifo_red=0;  
	}
}