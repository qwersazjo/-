#include "headfile.h"

uint8_t led_mode=0;
bsp_io_level_t now_staus,last_status=BSP_IO_LEVEL_HIGH;
char send_buf[20];
void Key_scan(void)
{
	R_IOPORT_PinRead(&g_ioport_ctrl,BSP_IO_PORT_00_PIN_01,&now_staus);
	if(now_staus==BSP_IO_LEVEL_LOW&&last_status==BSP_IO_LEVEL_HIGH)
	{
		led_mode++;
		led_mode%=2;
		if(led_mode==0)
			LED_OFF();
		else
		{
			sprintf(send_buf,"LED ON\r\n");
			R_SCI_UART_Write(&g_uart6_ctrl,(uint8_t *)send_buf,strlen(send_buf));
			LED_ON();
		}
	}
	last_status=now_staus;
}
