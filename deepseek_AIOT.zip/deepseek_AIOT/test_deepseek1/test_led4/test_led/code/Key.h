#ifndef _Key_h
#define _Key_h
#include "headfile.h"

void Key_scan(void);

#endif
