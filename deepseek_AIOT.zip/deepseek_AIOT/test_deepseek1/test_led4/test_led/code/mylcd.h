#ifndef _mylcd_h
#define _mylcd_h
#include "headfile.h"

#define SPI_TEST 0

void SPI_Init(void);
void SPI_RW_Drv(uint8_t *tbuff,uint8_t *rbuff,uint16_t size);
void SPI_RW_test(void);

#endif
