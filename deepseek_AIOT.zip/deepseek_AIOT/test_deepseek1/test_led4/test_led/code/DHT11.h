#ifndef _DHT11_h
#define _DHT11_h
#include "headfile.h"

void DHT11_Init(void);
uint8_t DHT11_ReadByte(void);
uint8_t DHT11_Read(void);

#endif
