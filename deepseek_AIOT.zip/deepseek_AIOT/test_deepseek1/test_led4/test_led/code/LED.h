#ifndef _LED_h
#define _LED_h
#include "headfile.h"

void Key_LED_Init(void);
void LED_ON(void);
void LED_OFF(void);

#endif
