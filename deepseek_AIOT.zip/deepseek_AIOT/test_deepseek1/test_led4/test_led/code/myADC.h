#ifndef _myADC_h
#define _myADC_h
#include "headfile.h"
extern double volt_value;

void ADC_Init(void);
double ADC_GetValue(void);

#endif
