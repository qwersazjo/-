#ifndef BSP_DTC_H
#define BSP_DTC_H

#include "hal_data.h"

// �ⲿ��������
extern int rtc_year_set;
extern int rtc_mon_set;
extern int rtc_mday_set;
extern int rtc_sec_set;
extern int rtc_min_set;
extern int rtc_hour_set;

extern int rtc_alarm_year_set;
extern int rtc_alarm_mon_set;
extern int rtc_alarm_mday_set;
extern int rtc_alarm_sec_set;
extern int rtc_alarm_min_set;
extern int rtc_alarm_hour_set;

extern int rtc_alarm_year_enable;
extern int rtc_alarm_mon_enable;
extern int rtc_alarm_mday_enable;
extern int rtc_alarm_wday_enable;
extern int rtc_alarm_sec_enable;
extern int rtc_alarm_min_enable;
extern int rtc_alarm_hour_enable;

// ��������
int calculate_wday(int year, int mon, int mday);
void RTC_Init(void);
void RTC_Alarm_Init(void);

// �������걣�ֲ���
#define Buzzer_sout()  \
    R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_06_PIN_05, BSP_IO_LEVEL_HIGH); \
    R_BSP_SoftwareDelay(500, BSP_DELAY_UNITS_MILLISECONDS); \
    R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_06_PIN_05, BSP_IO_LEVEL_LOW);

#endif