#ifndef _headfile_h
#define _headfile_h

#include "hal_data.h"
#include "stdio.h"
#include "stdint.h"
#include "stdlib.h"
#include "string.h"
#include "stdbool.h"
#include "math.h"

#include "LED.h"
#include "Key.h"
#include "myUsart.h"
#include "myADC.h"
#include "mylcd.h"
#include "drv_i2c_touch.h"
#include "DHT11.h"
#include "esp8266.h"
#include "max_i2c.h"
#include "algorithm.h"
#include "max30102.h"
#include "blood.h"

#endif
