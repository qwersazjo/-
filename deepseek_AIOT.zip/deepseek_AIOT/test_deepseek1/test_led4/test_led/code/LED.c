#include "headfile.h"

void Key_LED_Init(void)
{
	R_IOPORT_Open(&g_ioport_ctrl,&g_bsp_pin_cfg);
}

void LED_ON(void)
{
	R_IOPORT_PinWrite(&g_ioport_ctrl,BSP_IO_PORT_01_PIN_14,BSP_IO_LEVEL_LOW);
}

void LED_OFF(void)
{
	R_IOPORT_PinWrite(&g_ioport_ctrl,BSP_IO_PORT_01_PIN_14,BSP_IO_LEVEL_HIGH);
}

//R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_SECONDS);  ��ʱ����
