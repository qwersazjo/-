/* generated vector source file - do not edit */
        #include "bsp_api.h"
        /* Do not build these data structures if no interrupts are currently allocated because IAR will have build errors. */
        #if VECTOR_DATA_IRQ_COUNT > 0
        BSP_DONT_REMOVE const fsp_vector_t g_vector_table[BSP_ICU_VECTOR_NUM_ENTRIES] BSP_PLACE_IN_SECTION(BSP_SECTION_APPLICATION_VECTORS) =
        {
                        [0] = sci_uart_rxi_isr, /* SCI6 RXI (Receive data full) */
            [1] = sci_uart_txi_isr, /* SCI6 TXI (Transmit data empty) */
            [2] = sci_uart_tei_isr, /* SCI6 TEI (Transmit end) */
            [3] = sci_uart_eri_isr, /* SCI6 ERI (Receive error) */
            [4] = iic_master_rxi_isr, /* IIC0 RXI (Receive data full) */
            [5] = iic_master_txi_isr, /* IIC0 TXI (Transmit data empty) */
            [6] = iic_master_tei_isr, /* IIC0 TEI (Transmit end) */
            [7] = iic_master_eri_isr, /* IIC0 ERI (Transfer error) */
            [8] = gpt_counter_overflow_isr, /* GPT0 COUNTER OVERFLOW (Overflow) */
            [9] = sci_uart_rxi_isr, /* SCI9 RXI (Receive data full) */
            [10] = sci_uart_txi_isr, /* SCI9 TXI (Transmit data empty) */
            [11] = sci_uart_tei_isr, /* SCI9 TEI (Transmit end) */
            [12] = sci_uart_eri_isr, /* SCI9 ERI (Receive error) */
            [13] = sci_uart_rxi_isr, /* SCI0 RXI (Receive data full) */
            [14] = sci_uart_txi_isr, /* SCI0 TXI (Transmit data empty) */
            [15] = sci_uart_tei_isr, /* SCI0 TEI (Transmit end) */
            [16] = sci_uart_eri_isr, /* SCI0 ERI (Receive error) */
            [17] = rtc_alarm_periodic_isr, /* RTC ALARM (Alarm interrupt) */
            [18] = rtc_alarm_periodic_isr, /* RTC PERIOD (Periodic interrupt) */
            [19] = rtc_carry_isr, /* RTC CARRY (Carry interrupt) */
            [20] = sci_uart_rxi_isr, /* SCI7 RXI (Receive data full) */
            [21] = sci_uart_txi_isr, /* SCI7 TXI (Transmit data empty) */
            [22] = sci_uart_tei_isr, /* SCI7 TEI (Transmit end) */
            [23] = sci_uart_eri_isr, /* SCI7 ERI (Receive error) */
        };
        #if BSP_FEATURE_ICU_HAS_IELSR
        const bsp_interrupt_event_t g_interrupt_event_link_select[BSP_ICU_VECTOR_NUM_ENTRIES] =
        {
            [0] = BSP_PRV_VECT_ENUM(EVENT_SCI6_RXI,GROUP0), /* SCI6 RXI (Receive data full) */
            [1] = BSP_PRV_VECT_ENUM(EVENT_SCI6_TXI,GROUP1), /* SCI6 TXI (Transmit data empty) */
            [2] = BSP_PRV_VECT_ENUM(EVENT_SCI6_TEI,GROUP2), /* SCI6 TEI (Transmit end) */
            [3] = BSP_PRV_VECT_ENUM(EVENT_SCI6_ERI,GROUP3), /* SCI6 ERI (Receive error) */
            [4] = BSP_PRV_VECT_ENUM(EVENT_IIC0_RXI,GROUP4), /* IIC0 RXI (Receive data full) */
            [5] = BSP_PRV_VECT_ENUM(EVENT_IIC0_TXI,GROUP5), /* IIC0 TXI (Transmit data empty) */
            [6] = BSP_PRV_VECT_ENUM(EVENT_IIC0_TEI,GROUP6), /* IIC0 TEI (Transmit end) */
            [7] = BSP_PRV_VECT_ENUM(EVENT_IIC0_ERI,GROUP7), /* IIC0 ERI (Transfer error) */
            [8] = BSP_PRV_VECT_ENUM(EVENT_GPT0_COUNTER_OVERFLOW,GROUP0), /* GPT0 COUNTER OVERFLOW (Overflow) */
            [9] = BSP_PRV_VECT_ENUM(EVENT_SCI9_RXI,GROUP1), /* SCI9 RXI (Receive data full) */
            [10] = BSP_PRV_VECT_ENUM(EVENT_SCI9_TXI,GROUP2), /* SCI9 TXI (Transmit data empty) */
            [11] = BSP_PRV_VECT_ENUM(EVENT_SCI9_TEI,GROUP3), /* SCI9 TEI (Transmit end) */
            [12] = BSP_PRV_VECT_ENUM(EVENT_SCI9_ERI,GROUP4), /* SCI9 ERI (Receive error) */
            [13] = BSP_PRV_VECT_ENUM(EVENT_SCI0_RXI,GROUP5), /* SCI0 RXI (Receive data full) */
            [14] = BSP_PRV_VECT_ENUM(EVENT_SCI0_TXI,GROUP6), /* SCI0 TXI (Transmit data empty) */
            [15] = BSP_PRV_VECT_ENUM(EVENT_SCI0_TEI,GROUP7), /* SCI0 TEI (Transmit end) */
            [16] = BSP_PRV_VECT_ENUM(EVENT_SCI0_ERI,GROUP0), /* SCI0 ERI (Receive error) */
            [17] = BSP_PRV_VECT_ENUM(EVENT_RTC_ALARM,GROUP1), /* RTC ALARM (Alarm interrupt) */
            [18] = BSP_PRV_VECT_ENUM(EVENT_RTC_PERIOD,GROUP2), /* RTC PERIOD (Periodic interrupt) */
            [19] = BSP_PRV_VECT_ENUM(EVENT_RTC_CARRY,GROUP3), /* RTC CARRY (Carry interrupt) */
            [20] = BSP_PRV_VECT_ENUM(EVENT_SCI7_RXI,GROUP4), /* SCI7 RXI (Receive data full) */
            [21] = BSP_PRV_VECT_ENUM(EVENT_SCI7_TXI,GROUP5), /* SCI7 TXI (Transmit data empty) */
            [22] = BSP_PRV_VECT_ENUM(EVENT_SCI7_TEI,GROUP6), /* SCI7 TEI (Transmit end) */
            [23] = BSP_PRV_VECT_ENUM(EVENT_SCI7_ERI,GROUP7), /* SCI7 ERI (Receive error) */
        };
        #endif
        #endif