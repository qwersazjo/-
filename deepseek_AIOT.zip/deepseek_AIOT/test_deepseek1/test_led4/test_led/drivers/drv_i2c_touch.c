#include "headfile.h"
//#include "font.h"
/*MISO:P100  LED/Black:P004  SCK:P102  MOSI:P101  RS:105  RST:400  CS:003*/

#if DRV_TOUCH

uint16_t LCD_Buf[320*480];
volatile bool tx_flag=false;  //������ɱ�־λ

/*���ýṹ�����*/
Display_device LCD_Device=
{
	.name="ST7796S",
	.base_RAM=LCD_Buf,
	.wXres=320,
	.wYres=480,
	.wpixel=16,
	.size=320*480*16/8,
	.Init=LCD_Init,
	.DisplayON=LCD_DisplayON,
	.DisplayOFF=LCD_DisplayOFF,
	.Flush=LCD_Flush,
	.SetDisplayWindow=LCD_SetWindow,
	.Setpixel=LCD_Setpiexl
};

void sci_spi_callback(spi_callback_args_t * p_args)
{
	if(p_args->event==SPI_EVENT_TRANSFER_COMPLETE)  //������ɴ����ж�
		tx_flag=true;
}

/*
	@brief   �շ���ɵȴ�����
	@parame	 ��
	@retval  ��
*/
void SPI_RW_Timewait(void)
{
	uint16_t utime=500;
	while(!tx_flag&&utime)
	{
		R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MILLISECONDS);
		utime--;
	}
	tx_flag=false;
}

void LCD_WriteCS(CS pin_status)
{
	g_ioport.p_api->pinWrite(&g_ioport_ctrl,BSP_IO_PORT_00_PIN_03,(bsp_io_level_t)pin_status);
}

void LCD_WriteReset(Reset pin_status)
{
	g_ioport.p_api->pinWrite(&g_ioport_ctrl,BSP_IO_PORT_04_PIN_00,(bsp_io_level_t)pin_status);
}

void LCD_WriteRS(RS pin_status)
{
	g_ioport.p_api->pinWrite(&g_ioport_ctrl,BSP_IO_PORT_01_PIN_05,(bsp_io_level_t)pin_status);
}

void LCD_WriteBlack(Black pin_status)
{
	g_ioport.p_api->pinWrite(&g_ioport_ctrl,BSP_IO_PORT_00_PIN_04,(bsp_io_level_t)pin_status);
}

/*
	@brief  LCDӲ����λ����
	@parame ��
	@retval ��
*/
void LCD_Reset(void)
{
	LCD_WriteReset(isreset);
	R_BSP_SoftwareDelay(100,BSP_DELAY_UNITS_MILLISECONDS);
	LCD_WriteReset(noreset);
	R_BSP_SoftwareDelay(50,BSP_DELAY_UNITS_MILLISECONDS);
}

/*
	@brief  LCDд�Ĵ��������
	@parame Ҫд��ļĴ���
	@retval ��
*/
void LCD_WriteReg(uint8_t reg)
{
	LCD_WriteRS(iscommand);
	g_spi0.p_api->write(&g_spi0_ctrl,(uint8_t *)&reg,1,SPI_BIT_WIDTH_8_BITS);
	SPI_RW_Timewait();
}

/*
	@brief  LCDд�Ĵ������ݺ���
	@parame Ҫд�������
	@retval ��
*/
void LCD_Writedat(uint8_t dat)
{
	LCD_WriteRS(isdata);
	g_spi0.p_api->write(&g_spi0_ctrl,(uint8_t *)&dat,1,SPI_BIT_WIDTH_8_BITS);
	SPI_RW_Timewait();
}

/*
	@brief  LCD����д���ݺ���
	@parame Buf:Ҫд�������  size:Ҫд������ݴ�С
	@retval ��
*/
void LCD_WriteBuf(uint8_t *buf,uint32_t size)
{
	LCD_WriteReg(0x3C);
    LCD_WriteRS(isdata);
    uint8_t *pbuf =buf;
    while(size)
    {
        uint32_t length = 0;
        if(size<65536)
            length = (uint16_t)size;
        else
            length = 65535;
        fsp_err_t err = g_spi0.p_api->write(g_spi0.p_ctrl, pbuf, length, SPI_BIT_WIDTH_8_BITS);
        assert(FSP_SUCCESS==err);
        SPI_RW_Timewait();
        size = size - length;
        pbuf = pbuf + length;
    }
}

/*
	@brief  ��ȡ�豸
	@parame ��
	@retval �豸�Ľṹ��
*/
struct Display_device *LCDGetDevice(void)
{
	return &LCD_Device;
}

/*
	@brief  ��ʾ��������ʾ����
	@parame dev:�豸����
	@retval ��
*/
void LCD_DisplayON(struct Display_device *dev)
{
	if(dev->name==NULL) return;
	LCD_WriteReg(0X29);
}

/*
	@brief  ��ʾ���ر���ʾ����
	@parame dev:�豸����
	@retval ��
*/
void LCD_DisplayOFF(struct Display_device *dev)
{
	if(dev->name==NULL) return;
	LCD_WriteReg(0X28);
}

/*
	@brief  ��ʾ�����ô��ں���
	@parame dev:�豸����  wX1:X1��ֵ  wY1:Y1��ֵ  wX2:X2��ֵ  wY2:Y2��ֵ
	@retval ��
*/
void LCD_SetWindow(struct Display_device *dev,uint16_t wX1,uint16_t wY1,uint16_t wX2,uint16_t wY2)
{
	if(NULL == dev->name)    return;
    /*�����е�ַ*/
    LCD_WriteReg(0x2A);
    LCD_Writedat((uint8_t)(wX1>>8));       // ��ʼ��ַ�ȸߺ��
    LCD_Writedat((uint8_t)(0x00FF&wX1));
    LCD_Writedat((uint8_t)(wX2>>8));       // ������ַ�ȸߺ��
    LCD_Writedat((uint8_t)(0x00FF&wX2));
    /*�����е�ַ*/
    LCD_WriteReg(0x2B);
    LCD_Writedat((uint8_t)(wY1>>8));
    LCD_Writedat((uint8_t)(0x00FF&wY1));
    LCD_Writedat((uint8_t)(wY2>>8));
    LCD_Writedat((uint8_t)(0x00FF&wY2));
}

/*
	@brief  ȫ��ˢ�º�����һ���԰�base_RAM���������ȫ��������Ļ
	@parame dev:�豸����
	@retval ��
*/
void LCD_Flush(struct Display_device *dev)
{
	if(dev->name==NULL) return;
	LCD_WriteBuf((uint8_t*)dev->base_RAM,(uint32_t)dev->size);
}

int LCD_Setpiexl(struct Display_device *dev,uint16_t wX,uint16_t wY,uint16_t color)
{
	if(NULL == dev->name)    return -1;
    if (wX >= dev->wXres || wY >= dev->wYres)
        return -1;
    uint16_t *buf = (unsigned short*)dev->base_RAM;
    buf[wY * dev->wXres + wX] = (unsigned short)color;
    return 0;
}

void LCD_Init(struct Display_device *dev)
{
	if(NULL == dev->name)    return;
    /*��SPI�豸��ɳ�ʼ��*/
	fsp_err_t status =R_SCI_SPI_Open(&g_spi0_ctrl,&g_spi0_cfg);
    if(status==FSP_SUCCESS)
        printf("Success to open device:spi0\r\n");
    else
        printf("Failed to open device:spi0\r\n");
    /*��ʼ����Ļ�豸*/
    LCD_Reset(); 						//LCD��λ
    LCD_WriteCS(isseclet);
    LCD_WriteBlack(islight);  			//��������
    LCD_WriteReg(0x11);
    LCD_WriteReg(0x20);
    LCD_WriteReg(0x36);
    LCD_Writedat(0x40);
    LCD_WriteReg(0x3A);
    LCD_Writedat(0x55);
    LCD_WriteReg(0x13);
    LCD_WriteReg(0x29);
}

void LCD_Display(void)
{
    Display_device *ptDispDev = LCDGetDevice();
    if(NULL == ptDispDev)
    {
        printf("Failed to get LCD device!\r\n");
        return;
    }
    /*��ʼ����ʾ�豸*/
    ptDispDev->Init(ptDispDev);
    /*������Ļ��ʾ����*/
    ptDispDev->SetDisplayWindow(ptDispDev, 0, 0, ptDispDev->wXres - 1, ptDispDev->wYres - 1);
    /*�����Ļ*/
    memset((uint8_t*)ptDispDev->base_RAM, 0x00, ptDispDev->size);
    ptDispDev->Flush(ptDispDev);
    /* ��һ��ʵ��Բ */
    uint16_t x = 0, y = 0, r = 100;
    for(x = ((ptDispDev->wXres>>1) - r); x<((ptDispDev->wXres>>1) + r); x++)
    {
        for(y = ((ptDispDev->wYres>>1) - r); y<((ptDispDev->wYres>>1) + r); y++)
        {
            if(((x-(ptDispDev->wXres>>1)) * (x-(ptDispDev->wXres>>1))+(y-(ptDispDev->wYres>>1)) * (y-(ptDispDev->wYres>>1))) <= r*r)
            {
                ptDispDev->Setpixel(ptDispDev, x, y, FLOYRGB565(255, 255, 255));
            }
        }
    }
    ptDispDev->Flush(ptDispDev);
}

#endif
